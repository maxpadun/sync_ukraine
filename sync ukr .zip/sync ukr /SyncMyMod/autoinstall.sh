#!/bin/sh
#########################################################################################################################################################
#																Check if Mods Tools are installed														#
#########################################################################################################################################################
if [[ ! -f "/fs/rwdata/dev/utserviceutility" || ! -f "/fs/rwdata/dev/patch" || ! -f "/fs/rwdata/dev/remount_rw.sh" || ! -f "/fs/rwdata/dev/remount_ro.sh" ]]; then
	slay APP_SUM
	slay -s 9 NAV_Manager
	slay -s 9 fordhmi
	slay HMI_AL
	display_image -file=/fs/usb0/SyncMyMod/installation_aborted.png -display=2 &
	while [ -e /fs/usb0 ]; do
		sleep 1
	done
	shutdown
else

# Mount the Sync 3 OS partition with READ / WRITE permissions.
# This is mandatory for 99,99% of the mods.
. /fs/rwdata/dev/remount_rw.sh
sleep 1

echo ">Copying Started ...." >> /tmp/popup.txt
/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt ;
#########################################################################################################################################################
#																Choose the folder or file to copy from/to														#
#########################################################################################################################################################
cp -r /fs/usb0/SyncMyMod/fordhmi_ru_RU.qm /fs/mp/fordhmi/translations/fordhmi_ru_RU.qm

echo ">Copying files  ...." >> /tmp/popup.txt
/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt ;
	#########################################################################################################################################################
	#																Remount FS as RO																		#
	#########################################################################################################################################################
	. /fs/rwdata/dev/remount_ro.sh

echo ">Copying Completed ...." >> /tmp/popup.txt
/fs/rwdata/dev/utserviceutility popup /tmp/popup.txt ;
	#########################################################################################################################################################
	#																Display success image and reboot														#
	#########################################################################################################################################################
	sleep 1
	slay APP_SUM
	slay -s 9 NAV_Manager
	slay -s 9 fordhmi
	slay HMI_AL
	display_image -file=/fs/usb0/SyncMyMod/installation_completed.png -display=2 &
	while [ -e /fs/usb0 ]; do
		sleep 1
	done
	shutdown
fi